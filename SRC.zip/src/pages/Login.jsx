import React, { useState } from "react";
import "./Login.css";
import { useNavigate } from "react-router-dom";
import { TbLockPassword } from "react-icons/tb";
import { CiUser } from "react-icons/ci";
import { FaEye, FaEyeSlash } from "react-icons/fa";

function Login({role,setRole}) {

  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!role) {
      alert("Please select a role first");
      return;
    }

    if (role) {
      navigate("/admin-dashboard");
    } 
  };

  return (
    <div className="Login-container">
      <div className="Left-container">
        <h3>Academic Nexus</h3>
        <h1>Final Year project Evaluation System</h1>
        <p>
          Review, evaluate and manage university projects efficiently with our
          precision-engineered evaluation tool.
        </p>
      </div>

      <div className="right-container">
        <h3>Welcome back!</h3>
        <p>Please sign in to access your portal</p>

        <div className="buttons-container">
          <button
            className={`student-btn ${role === "admin" ? "active-role-btn" : ""}`}
            onClick={() => setRole("admin")}
          >
            Login as Admin
          </button>

          <button
            className={`teacher-btn ${role === "judge" ? "active-role-btn" : ""}`}
            onClick={() => setRole("judge")}
          >
            Login as Judge
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <label>
            {role === "admin"
              ? "Enter Your College No or Email"
              : "Enter Your Admin ID or Email"}
          </label>

          <div className="name-container">
            <CiUser className="name-icon" />
            <input
              placeholder="enter your name or email."
              type="text"
              className="name-input"
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </div>

          <label>Enter your password</label>
          <div className="password-container">
            <TbLockPassword className="password-icon" />
            <input
              type={showPassword ? "text" : "password"}
              className="password-input"
              placeholder="Enter your password"
              onChange={(e) => setPassword(e.target.value)}
              value={password}
            />
            {showPassword ? (
              <FaEyeSlash
                className="right-icon"
                onClick={() => setShowPassword(false)}
              />
            ) : (
              <FaEye
                className="right-icon"
                onClick={() => setShowPassword(true)}
              />
            )}
          </div>

          <button type="submit">Sign in</button>
        </form>
      </div>
    </div>
  );
}

export default Login;