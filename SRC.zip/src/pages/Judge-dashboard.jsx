import React from "react";
function JudgeDashboard(){
    return(
        <>
        <h1>
        Teacher dashboard
        </h1>
        <p>This is a teachers dashboard</p>
        </>
    )
}
export default JudgeDashboard;